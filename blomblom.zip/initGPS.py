import serial
import pynmea2
from math import pi, cos, sin, acos
import datetime
import time


class GPS:
    '''doc'''

    def __init__(self, serial_port='/dev/ttyUSB1', baudrate=115200):
        self.serial_port = serial_port
        self.baudrate = baudrate
        self.lat, self.lon = 0.0, 0.0
        self.speed_kph = 0.0
        self.last_lon, self.last_lat, self.last_timestamp = 0.0, 0.0, datetime.time()
        self.gps = None
        self.gps_active = False 
        

        

    def connect(self):
        '''doc'''
        try:
            self.gps = serial.Serial(self.serial_port, baudrate=self.baudrate)
            self.gps.timeout = 30
        except serial.serialutil.SerialException:
            print('\nERROR: Either, GPS is not or you dont have permission to read...\nPlease write: sudo chmod a+rw /dev/ttyUSB0 in the terminal and try again.\n')

    # def InitGPS(self):
    #     f = open("altus_init_script_current.txt", "r")
    #     i=0
    #     for x in f:
    #         x = x+'\n\r'
    #         self.gps.write(x.encode())
    #         time.sleep(5)
    #         print(x)
            
            
    #         time.sleep(1)
            
    #         num = self.gps.inWaiting()
    #         try:
    #             print(self.gps.read(num).decode())
    #         except:
    #             print(self.gps.read(num))
            
    #         #print(self.gps.read(num))

    #         # if (i == 6 or i == 34 or i == 35 or i == 37 or i == 44):
            
    #         #     time.sleep(3)
            
    #         # elif (i > 37 and i < 45):
            
    #         #     time.sleep(0)
            
    #         # else:
            
    #         #     time.sleep(0.5)
            

    #         # i=i+1
            
    #     f.close()
    #     #self.gps.close()


    def InitGPS(self):
        f = open("altus_init_script_current.txt", "r")
        i=0
        tmpstr = ""
        for x in f: #37-43
            print(50*"-")
            i += 1
            if i>=39 and i<43:
                tmpstr += x
                continue
            elif i==43:
                tmpstr += x
                print(tmpstr)
                self.gps.write(tmpstr.encode())
            else:
                x = x+'\n\r'
                print(x)
                self.gps.write(x.encode())

            
            # #time.sleep(3)
            # if '+++' in x:
            #     #time.sleep(3)
            #     continue
            if x == "AT\n\r":
                continue

            time.sleep(1)
            
            num = self.gps.inWaiting()
            try:
                print(self.gps.read(num).decode())
            except:
                print(self.gps.read(num))

            
            # if (i == 6 or i == 34 or i == 35 or i == 37 or i == 44):
            
            #     time.sleep(3)
            
            # elif (i > 37 and i < 45):
            
            #     time.sleep(0)
            
            # else:
            
            #     time.sleep(0.5)
            

            # i=i+1
            
        f.close()
        
    
    def poll(self):
        '''doc'''
        lat, lon, timestamp = 0.0, 0.0, 0.0
        if self.gps is None: return
        data = self.gps.readline().decode('latin-1')
        message = data[0:6]
        if (message == '$GPRMC'):
            parts = data.split(',')
            if parts[2]=="V":
                self.gps_active = False
                self.speed_kph=0
                return None
            elif parts[2]=="A":
                self.gps_active = True
                self.speed_kph = 1.852 * float(parts[7])
        if(message=='$GPGGA'):
            y = pynmea2.parse(data)
            if y.gps_qual>=1:
                self.lat = y.latitude
                self.lon = y.longitude
            print('{0} {1} {2}'.format(y.gps_qual, self.lat, self.lon))

        

            



# Example of usage
if __name__ == "__main__":
    n = 0
    gps = GPS()
    gps.connect()
    gps.InitGPS()
    i = 0
    while 1:
        gps.poll()
        i+=1
        if i==100:
            break
    gps.gps.close()

