""" Common Vision Blox OPCUA module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/OpcUa/'>Common Vision Blox-Tool OPC UA</a>
"""

import cvb as _cvb
import sys as _sys
import os as _os

import _opcua

_mbi_id = _opcua._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())

# classes
Subscription = _opcua.Subscription
BrowseFilter = _opcua.BrowseFilter 

Client = _opcua.Client
Server = _opcua.Server

MethodNodeArgument = _opcua.MethodNodeArgument

NodeID = _opcua.NodeID

BaseNode = _opcua.BaseNode

ObjectNode = _opcua.ObjectNode
VariableNode = _opcua.VariableNode
IntegerNode = _opcua.IntegerNode
FloatNode = _opcua.FloatNode
StringNode = _opcua.StringNode
MethodNode = _opcua.MethodNode

# enomnoms
_ReferenceDirection = _opcua.ReferenceDirection
ReferenceDirection = _opcua.ReferenceDirection()

_NodeIDType = _opcua.NodeIDType
NodeIDType = _opcua.NodeIDType()

_ArgumentType = _opcua.ArgumentType
ArgumentType = _opcua.ArgumentType()

_NodeClass = _opcua.NodeClass
NodeClass = _opcua.NodeClass()

_Access = _opcua.Access
Access = _opcua.Access()

_ConnectionStatus = _opcua.ConnectionStatus
ConnectionStatus = _opcua.ConnectionStatus()

_DataType = _opcua.DataType
DataType = _opcua.DataType()

_ReferenceType = _opcua.ReferenceType
ReferenceType = _opcua.ReferenceType()

_AttributeID = _opcua.AttributeID
AttributeID = _opcua.AttributeID() 

_Namespace0NodeID = _opcua.Namespace0NodeID
Namespace0NodeID = _opcua.Namespace0NodeID() 

_BrowseSubType = _opcua.BrowseSubType
BrowseSubType = _opcua.BrowseSubType()