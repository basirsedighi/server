""" Common Vision Blox Match3D module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/Match3D/'>Common Vision Blox-Tool Match3D</a>
"""

import cvb as _cvb
import sys as _sys
import os as _os







import _match_3d

_mbi_id = _match_3d._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())

MatchingResult = _match_3d.MatchingResult
MatchingParameters = _match_3d.MatchingParameters

match_downsampled_point_clouds = _match_3d.match_downsampled_point_clouds
distance_rms = _match_3d.distance_rms