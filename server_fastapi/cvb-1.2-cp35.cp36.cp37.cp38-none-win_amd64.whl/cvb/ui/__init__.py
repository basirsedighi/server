""" Common Vision Blox UI module for Python

All components within this namespace depend on the Qt5 library. In order to work properly, you must have a PySide2 installed.

"""

import cvb as _cvb
import sys as _sys
import os as _os







import _ui

_mbi_id = _ui._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())


from PySide2.QtCore import QObject as _QObject
from PySide2.QtCore import QRectF as _QRectF
from PySide2.QtCore import QPointF as _QPointF
from PySide2.QtCore import Qt as _Qt
from PySide2.QtCore import Property as _Property
from PySide2.QtCore import Signal as _Signal
from PySide2.QtCore import Slot as _Slot
from PySide2.QtQml import qmlRegisterType as _qmlRegisterType
from PySide2.QtQuick import QQuickPaintedItem as _QQuickPaintedItem
from PySide2.QtQuick import QQuickItem as _QQuickItem
from PySide2.QtGui import QImage as _QImage


from math import floor as _floor


_UploadMode = _ui.UploadMode
UploadMode =  _ui.UploadMode()

_ZoomID = _ui.ZoomID
ZoomID =  _ui.ZoomID()

_AutoRefresh = _ui.AutoRefresh
AutoRefresh = _ui.AutoRefresh()


def qt_to_cvb_rect(rect):
  """(rect)
  Convenience converter for rectangles.

  Parameters
  ----------
    rect : Qt5 rectangle
      A Qt5 rectangle

  Returns
  -------
	  cvb.Rect
		  A rectangle used by the cvb module.
  """
  return _cvb.Rect(rect.left(), rect.top(), rect.right(), rect.bottom())

def cvb_to_qt_rect(rect):
  """(rect)
  Convenience converter for rectangles.

  Parameters
  ----------
    rect : cvb.Rect
      A rectangle used by the cvb module.

  Returns
  -------
	  Qt rect
		  A Qt5 rectangle
  """
  return _QRectF(rect.left, rect.top, rect.width, rect.height)

def qt_to_cvb_point(point):
  """(point)
  Convenience converter for points.

  Parameters
  ----------
    rect : Qt5 point
      A Qt5 point

  Returns
  -------
	  cvb.Point2D
		  2D point used by the cvb module.
  """
  return _cvb.Point2D(point.x(), point.y())

def cvb_to_qt_point(point):
  """(point)
  Convenience converter for points.

  Parameters
  ----------
    point : cvb.Point2D
      A 2D point used by the cvb module.

  Returns
  -------
	  Qt point
		  A Qt5 point
  """
  return _QPointF(point.x, point.y)





class ImageController(_QObject):
  """Controller object for the QML image view item.

  An instance of this class should be set as context property for QML context.
  In QML an instance of ImageViewItem can connect to this instance by binding it to its image property.

  """

  def __init__(self):
    super(ImageController, self).__init__(None)
    self._image = None
    self._event_cookie_data_updated = None


  def _get_width(self):
    """
    Width of the shared image in pixels.

    If no image is shared, return 0.

    This is a QML property!
    """
    if self._image is None:
      return 0
    else:
      return self._image.width

  def _get_height(self):
    """
    Height of the shared image in pixels.

    If no image is shared, return 0.

    This is a QML property!
    """
    if self._image is None:
      return 0
    else:
      return self._image.height

  def _get_planeCount(self):
    """
    Get the number of planes for this image.

    If no image is shared, return 0.

    This is a QML property!
    """
    if self._image is None:
      return 0
    else:
      return len(self._image.planes)

  @property
  def image(self):
    """Get the currently shared image."""
    return self._image

  @_Signal
  def _notify_refreshImage(self):
    pass

  @_Signal
  def _notify_refresh(self):
    pass




  width = _Property(int, _get_width, notify=_notify_refreshImage)
  height = _Property(int, _get_height, notify=_notify_refreshImage)
  planeCount = _Property(int, _get_planeCount, notify=_notify_refreshImage)


  def release_refresh_share(self):
    """()
    Releases the shared image.

    Use this method if you must release the shared image manually.
    Setting a new shared image and destroying this image view will automatically release the shared image.
    """
    self._image = None

  def refresh(self, image = None, auto_refresh = AutoRefresh.Off):
    """(image = None, auto_refresh = cvb.ui.AutoRefresh.Off)
    Share the image and refresh the view.

    Parameters
    ----------
    image : cvb.Image
      The image, which will be shared with the display.

    auto_refresh : cvb.ui.AutoRefresh
      Switch to control automatic refreshing.

    """
    if image is not None:
      self._unregister_event_image_data_updated()
      self._image = image
      if auto_refresh == AutoRefresh.On:
        self._event_cookie_data_updated = image.register_event_pixel_content_changed(lambda image, rect: self.refresh())
    elif self._image is  None:
      return
    self._notify_refreshImage.emit()


  def _unregister_event_image_data_updated(self):
    if self._image is not None and self._event_cookie_data_updated is not None:
      self._image.unregister_event_pixel_content_changed(self._event_cookie_data_updated)




class ImageViewItem(_QQuickPaintedItem):
  """Image view item for QML.

  This class (or an extended subclass) should be registered in QML.
  The item provides an image display.
  Instances should only be created from QML.

  For convenience see ImageViewItem.register

  See examples for available properties.
  """

  @classmethod
  def register(cls, uri="CvbQuick", version_major = 1, version_minor = 0, qml_name = "ImageView"):
    """(cls, uri, version_major = 1, version_minor = 0, qml_name = "ImageView")
    Convenience method to register this type or a derived type in QML.

    Basically just calls qmlRegisterType(...).

    Parameters
    ----------
    uri : str
      URI forwarded to Qt.

    version_major : int
      Major version forwarded to Qt.

    version_minor : int
      Minor version forwarded to Qt.

    qml_name : str
      Name in QML forwarded to Qt.

    """
    _qmlRegisterType(cls, uri, version_major, version_minor, qml_name)

  def __init__(self, parent = None):
    super(ImageViewItem, self).__init__(parent)
    self._image = None
    self._dispatcher = _ui.ImageViewDispatcher(lambda : self._notify_zoom.emit())
    self.setClip(True)
    self.setAcceptedMouseButtons(_Qt.AllButtons)
    self.setAcceptHoverEvents(True)
    self._notify_image.connect(self.refresh)
    self._notify_viewRect.connect(self._on_view_rect_changed)
    self._notify_imageRect.connect(self._on_image_rect_changed)
    self._notify_zoom.connect(self._on_zoom_changed)
    self._notify_viewAnchor.connect(self._on_view_anchor_changed)


  @_Signal
  def _notify_imageRect(self):
    pass


  @_Signal
  def _notify_viewRect(self):
    pass


  @_Signal
  def _notify_sourceRect(self):
    pass


  @_Signal
  def _notify_targetRect(self):
    pass


  @_Signal
  def _notify_image(self):
    pass


  @_Signal
  def _notify_zoom(self):
    pass


  @_Signal
  def _notify_viewAnchor(self):
    pass


  @_Signal
  def _notify_imageAnchor(self):
    pass


  @_Signal
  def _notify_hover(self):
    pass





  @_Signal
  def _notify_upload_mode(self):
    pass


  @_Slot()
  def refresh(self):
    if self._image is None:
      return
    image = self._image.image
    if image is None:
      return
    self._dispatcher.upload_image(image, lambda: self._notify_imageRect.emit())
    self.update()


  @_Slot()
  def _on_view_rect_changed(self):
    self._update_source_target()


  @_Slot()
  def _on_image_rect_changed(self):
    self._update_source_target()


  @_Slot()
  def _on_zoom_changed(self):
    self._update_source_target()
    self.update()
    pass


  @_Slot()
  def _on_view_anchor_changed(self):
    target_point = self._dispatcher.map_view_to_target(self._dispatcher.view_anchor)
    target_point = self._dispatcher.limit_point_to_rect(target_point, self._dispatcher.target_rect)
    source_point = self._dispatcher.map_target_to_source(target_point)
    image_point = self._dispatcher.map_source_to_image(source_point)
    self._dispatcher.update_image_anchor(image_point, lambda: self._notify_imageAnchor.emit())

  @_Slot(result = bool)
  def try_zoom_in(self):
    """()
    Tries to zoom in.

    This method can becalled from QML!

    Returns
    -------
	  bool
		  True if successful, false otherwise.
    """
    result = self._dispatcher.try_zoom_in(lambda: self._notify_targetRect.emit(), lambda: self._notify_sourceRect.emit())
    self.update()
    if result:
      self._notify_zoom.emit()
      if self._dispatcher.upload_mode == UploadMode.Viewport:
        self.refresh()
    return result


  @_Slot(result = bool)
  def try_zoom_out(self):
    """()
    Tries to zoom out.

    This method can becalled from QML!

    Returns
    -------
	  bool
		  True if successful, false otherwise.
    """
    result = self._dispatcher.try_zoom_out(lambda: self._notify_targetRect.emit(), lambda: self._notify_sourceRect.emit())
    self.update()
    if result:
      self._notify_zoom.emit()
      if self._dispatcher.upload_mode == UploadMode.Viewport:
        self.refresh()
    return result


  @_Slot(_QPointF, result = bool)
  def try_translate(self, translation):
    """(translation)
    Tries to translate the target rectangle to a give point.

    This method can becalled from QML!

    Parameters
    ----------
    translation : Qt5 point
      Point interpreted as vector to translate.

    Returns
    -------
	  bool
		  True if successful, false otherwise.
    """
    result = self._dispatcher.try_translate(qt_to_cvb_point(translation), lambda: self._notify_sourceRect.emit())
    if self._dispatcher.upload_mode == UploadMode.Viewport:
      self.refresh()
    else:
      self.update()
    return result


  def paint(self, painter):
    if not self._dispatcher.is_buffer_valid:
      return
    screen_image = self._screen_image()
    if self._dispatcher.upload_mode == UploadMode.Image:
      painter.drawImage(cvb_to_qt_rect(self._dispatcher.target_rect), screen_image, cvb_to_qt_rect(self._dispatcher.source_rect))
    else:
      image = self._image.image
      if image is None:
        return
      painter.drawImage(cvb_to_qt_rect(self._dispatcher.target_rect), screen_image, cvb_to_qt_rect(self._dispatcher.source_rect_adj))


  def geometryChanged(self, newGeometry, oldGeometry):
    tmpGemorty = qt_to_cvb_rect(newGeometry)
    if tmpGemorty != self._dispatcher.view_rect:
      self._dispatcher.update_view_rect(tmpGemorty, lambda: self._notify_viewRect.emit())
    super(ImageViewItem, self).geometryChanged(newGeometry, oldGeometry)
    if self._dispatcher.upload_mode == UploadMode.Viewport:
      self.refreh()


  def wheelEvent(self, event):
    self._set_viewAnchor(self.mapFromGlobal(event.globalPosF()))
    numDegrees = event.angleDelta().y()

    if numDegrees <= -15:
      self.try_zoom_out()
    elif numDegrees >= 15:
      self.try_zoom_in()

  def mouseMoveEvent(self, event):
    if event.buttons() & _Qt.LeftButton:
      current_pos = qt_to_cvb_point(self.mapFromGlobal(event.globalPos()))
      if not self._dispatcher.is_last_mouse_position_valid:
        self._dispatcher.invalidate_last_mouse_position(current_pos)
        return
      self.try_translate(cvb_to_qt_point(current_pos - self._dispatcher.last_mouse_position))
      self._dispatcher.invalidate_last_mouse_position(current_pos)

  def mouseReleaseEvent(self, event):
    self._dispatcher.invalidate_last_mouse_position()

  def mousePressEvent(self, event):
    pass # nothing to skip the default implementation

  def hoverMoveEvent(self, event):
    hover_position = self._dispatcher.map_view_to_image(qt_to_cvb_point(event.posF()))
    if not self._dispatcher.image_rect.contains(hover_position):
      return
    self._dispatcher.update_hover_position(hover_position, lambda: self._notify_hover.emit())




  def _get_imageRect(self):
    """
    Get the rectangle described by the image buffer associated with the view.

    This is a QML property!
    """
    return cvb_to_qt_rect(self._dispatcher.image_rect)
  imageRect = _Property(_QRectF, _get_imageRect, notify=_notify_imageRect)


  def _get_viewRect(self):
    """
    Get the rectangle this items covers.

    This is a QML property!
    """
    return cvb_to_qt_rect(self._dispatcher.view_rect)
  viewRect = _Property(_QRectF, _get_viewRect, notify=_notify_viewRect)


  def _get_sourceRect(self):
    """
    Get the rectangle inside the image rectangle that is actually rendered.

    This is a QML property!
    """
    return cvb_to_qt_rect(self._dispatcher.source_rect)
  sourceRect = _Property(_QRectF, _get_sourceRect, notify=_notify_sourceRect)


  def _get_targetRect(self):
    """
    Get the rectangle inside the view rectangle  the image is actually rendered to.

    This is a QML property!
    """
    return cvb_to_qt_rect(self._dispatcher.target_rect)
  targetRect = _Property(_QRectF, _get_targetRect, notify=_notify_targetRect)


  def _get_image(self):
    """
    Get or set the image controller for this view item.

    Usually you set an image controller object as context property and assign it to the view's image property.

    This is a QML property!
    """
    return self._image

  def _set_image(self, image):
    if image is None:
      return
    self._image = image
    self._image._notify_refresh.connect(self.refresh)
    self._image._notify_refreshImage.connect(self.refresh)

  image = _Property(ImageController, _get_image, _set_image, notify=_notify_image)


  def __get_zoomID(self):
    """
    Get the zoom identifier for special zoom steps (as int, see cvb.ui.ZoomID).

    This is a QML property!
    """
    return self._dispatcher.zoom_id

  def _set_zoomID(self, id):
    self._dispatcher.update_zoom_id(id, lambda: self._notify_zoom.emit())

  zoomID = _Property(int, __get_zoomID, _set_zoomID, notify=_notify_zoom)

  def _get_zoomFactor(self):
    """
    Get or set the view's zoom factor.

    This is a QML property!
    """
    return self._dispatcher.zoom_factor

  def _set_zoomFactor(self, factor):
    self._dispatcher.update_zoom_factor(factor, lambda: self._notify_zoom.emit())

  zoomFactor = _Property(float, _get_zoomFactor, _set_zoomFactor, notify=_notify_zoom)


  def _get_uploadMode(self):
    """
    Set the current upload mode (as integer).

    This is a QML property!
    """
    return self._dispatcher.upload_mode

  def _set_uploadMode(self, factor):
    self._dispatcher.update_upload_mode(factor, lambda: self._notify_upload_mode.emit())

  uploadMode = _Property(int, _get_uploadMode, _set_uploadMode, notify=_notify_upload_mode)

  def _get_viewAnchor(self):
    """
    Get the reference point for mouse operations in view coordinates.

    This is a QML property!
    """
    return cvb_to_qt_point(self._dispatcher.view_anchor)

  def _set_viewAnchor(self, view_anchor):
    self._dispatcher.update_view_anchor(qt_to_cvb_point(view_anchor), lambda: self._notify_viewAnchor.emit())

  viewAnchor = _Property(_QPointF, _get_viewAnchor, _set_viewAnchor, notify=_notify_viewAnchor)


  def _get_imageAnchor(self):
    """
    Get the reference point for mouse operations in image coordinates.

    This is a QML property!
    """
    return cvb_to_qt_point(self._dispatcher.image_anchor)

  def _set_imageAnchor(self, image_anchor):
    self._dispatcher.update_image_anchor(qt_to_cvb_point(image_anchor), lambda: self._notify_imageAnchor.emit())

  imageAnchor = _Property(_QPointF, _get_imageAnchor, _set_imageAnchor, notify=_notify_imageAnchor)


  def _get_hoverPosition(self):
    """
    Get the point the mouse is hovering over.

    This is a QML property!
    """
    if not self._dispatcher.is_hover_position_valid:
      return _QPointF()
    return cvb_to_qt_point(self._dispatcher.hover_position)
  hoverPosition = _Property(_QPointF, _get_hoverPosition, notify=_notify_hover)


  def _get_hoverPixel(self):
    """
    The image pixel value the mouse is currently hovered over.

    If the value is undefined an empty list is returned.

    This is a QML property!
    """
    if self._image is None:
      return []
    image = self._image.image
    if image is None or not self._dispatcher.is_hover_position_valid:
      return []
    hover_position = self._dispatcher.hover_position
    hover_position.x = _floor(hover_position.x)
    hover_position.y = _floor(hover_position.y)
    if int(hover_position.x) == image.width:
      hover_position.x = hover_position.x - 1
    if int(hover_position.y) == image.height:
      hover_position.y = hover_position.y - 1
    return image.get_pixel(hover_position)
  hoverPixel = _Property("QVariantList", _get_hoverPixel, notify=_notify_hover)


  def _update_source_target(self):
    self._dispatcher.update_source_target(lambda: self._notify_targetRect.emit(), lambda: self._notify_sourceRect.emit())


  def _screen_image(self):
    data = self._dispatcher.buffer
    size = self._dispatcher.buffer_size
    return _QImage(data, int(size.width), int(size.height), _QImage.Format_ARGB32_Premultiplied)


class ImageLabelItem(_QQuickItem):
  """Image label item for QML.

  This class (or an extended subclass) should be registered in QML.
  The item provides an overlay object to draw into an image display (see cvb.ImageViewItem)
  Instances should only be created from QML.

  For convenience see ImageLabelItem.register

  See examples for available properties.
  """

  @classmethod
  def register(cls, uri="CvbQuick", version_major = 1, version_minor = 0, qml_name = "ImageLabel"):
    """(cls, uri, version_major = 1, version_minor = 0, qml_name = "ImageLabel")
    Convenience method to register this type or a derived type in QML.

    Basically just calls qmlRegisterType(...).

    Parameters
    ----------
    uri : str
      URI forwarded to Qt.

    version_major : int
      Major version forwarded to Qt.

    version_minor : int
      Minor version forwarded to Qt.

    qml_name : str
      Name in QML forwarded to Qt.

    """
    _qmlRegisterType(cls, uri, version_major, version_minor, qml_name)

  def __init__(self, parent = None):
    super(ImageLabelItem, self).__init__(parent)
    self._image_x = 0.0
    self._image_y = 0.0
    self._label_scale = 0
    self._image_view = None
    self.setTransformOrigin(_QQuickItem.TopLeft)
    self._notify_imageView.connect(self._on_image_view_changed)



  @_Slot()
  def _on_image_x_changed(self):
    if self._image_view is None:
      return
    source_rect = self._image_view._get_sourceRect()
    source_x = self._image_x - source_rect.x()
    target_x = source_x * self._image_view._get_zoomFactor()
    target_rect = self._image_view._get_targetRect()
    view_x = target_x + target_rect.x()
    try:
      self.setX(view_x)
    except:
      pass

  @_Slot()
  def _on_image_y_changed(self):
    if self._image_view is None:
      return
    source_rect = self._image_view._get_sourceRect()
    source_y = self._image_y - source_rect.y()
    target_y = source_y * self._image_view._get_zoomFactor()
    target_rect = self._image_view._get_targetRect()
    view_y = target_y + target_rect.y()
    try:
      self.setY(view_y)
    except:
      pass

  @_Slot()
  def _on_image_view_changed(self):
    self._setup_connections()
    self._on_image_x_changed()
    self._on_image_y_changed()
    self._on_label_scale_changed()

  @_Slot()
  def _on_label_scale_changed(self):
    if self._label_scale == 0:
      try:
        self.setScale(1.0)
      except:
        pass
      return
    if self._image_view is None:
      return
    try:
      self.setScale(self._image_view._get_zoomFactor())
    except:
      pass


  @_Signal
  def _notify_imageX(self):
    pass

  @_Signal
  def _notify_imageY(self):
    pass

  @_Signal
  def _notify_imageView(self):
    pass

  @_Signal
  def _notify_labelScale(self):
    pass

  def _get_imageX(self):
    """
    Get or set the X position of this label on the image.

    This is a QML property!
    """
    return self._image_x

  def _set_imageX(self, image_x):
    if image_x == self._image_x:
      return
    self._image_x = image_x
    self._notify_imageX.emit()

  imageX = _Property(float, _get_imageX, _set_imageX, notify=_notify_imageX)

  def _get_imageY(self):
    """
    Get or set the Y position of this label on the image.

    This is a QML property!
    """
    return self._image_y

  def _set_imageY(self, image_y):
    if image_y == self._image_y:
      return
    self._image_y = image_y
    self._notify_imageY.emit()

  imageY = _Property(float, _get_imageY, _set_imageY, notify=_notify_imageY)


  def _get_labelScale(self):
    """
    Get or set the label scale behaviour (as int, see cvb.ui.labelScale).

    This is a QML property!
    """
    return self._label_scale

  def _set_labelScale(self, label_scale):
    if label_scale == self._label_scale:
      return
    self._label_scale = label_scale
    self._notify_labelScale.emit()

  labelScale = _Property(int, _get_labelScale, _set_labelScale, notify=_notify_labelScale)

  def _get_imageView(self):
    """
    Get or set the image view for this label.

    This is a QML property!
    Use this property in QML to associate the label with an image view.
    """
    return self._image_view

  def _set_imageView(self, image_view):
    if image_view is None:
      return
    self._image_view = image_view
    self._notify_imageView.emit()


  imageView = _Property(ImageViewItem, _get_imageView, _set_imageView, notify=_notify_imageView)

  def _setup_connections(self):
    if self._image_view is None:
      return
    self._notify_imageX.connect(self._on_image_x_changed)
    self._notify_imageY.connect(self._on_image_y_changed)
    self._notify_labelScale.connect(self._on_label_scale_changed)
    self._image_view._notify_sourceRect.connect(self._on_image_x_changed)
    self._image_view._notify_sourceRect.connect(self._on_image_y_changed)
    self._image_view._notify_targetRect.connect(self._on_image_x_changed)
    self._image_view._notify_targetRect.connect(self._on_image_y_changed)
    self._image_view._notify_zoom.connect(self._on_image_x_changed)
    self._image_view._notify_zoom.connect(self._on_image_y_changed)
    self._image_view._notify_zoom.connect(self._on_label_scale_changed)

