""" Common Vision Blox GevServer module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/GEVServer/'>Common Vision Blox-Tool GigE Vision Server</a>
"""

import cvb as _cvb
import sys as _sys
import os as _os

import _gevserver

_mbi_id = _gevserver._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())

# enums
_NodeList = _gevserver.NodeList
NodeList = _gevserver.NodeList()
_DriverType = _gevserver.DriverType
DriverType = _gevserver.DriverType()
_ServerInitType = _gevserver.ServerInitType
ServerInitType = _gevserver.ServerInitType()
_ServerEvent = _gevserver.ServerEvent
ServerEvent = _gevserver.ServerEvent()
_NodeEvent = _gevserver.NodeEvent
NodeEvent = _gevserver.NodeEvent()
_NodeType = _gevserver.NodeType
NodeType = _gevserver.NodeType()
_Info = _gevserver.Info
Info = _gevserver.Info()
_NodeInfo = _gevserver.NodeInfo
NodeInfo = _gevserver.NodeInfo()
_NumberSign = _gevserver.NumberSign
NumberSign = _gevserver.NumberSign()
_PayloadType = _gevserver.PayloadType
PayloadType = _gevserver.PayloadType()
_State = _gevserver.State
State = _gevserver.State()
_NameSpace = _gevserver.NameSpace
NameSpace = _gevserver.NameSpace()

BooleanNode = _gevserver.BooleanNode
CategoryNode = _gevserver.CategoryNode
CommandNode = _gevserver.CommandNode
EnumEntryNode = _gevserver.EnumEntryNode
EnumerationNode = _gevserver.EnumerationNode
IntRegNode = _gevserver.IntRegNode
Int64RegNode = _gevserver.Int64RegNode
Int32RegNode = _gevserver.Int32RegNode
IntegerNode = _gevserver.IntegerNode
IntSwissKnifeNode = _gevserver.IntSwissKnifeNode
IntegerBaseNode = _gevserver.IntegerBaseNode
Node = _gevserver.Node
SelectorNode = _gevserver.SelectorNode
StringNode = _gevserver.StringNode
StringRegNode = _gevserver.StringRegNode
ValueNode = _gevserver.ValueNode

Stream = _gevserver.Stream

NodeMap = _gevserver.NodeMap
Server = _gevserver.Server

ImageBufferDescription = _gevserver.ImageBufferDescription;
ChunkImageBufferDescription = _gevserver.ChunkImageBufferDescription;

LogicalNetworkInterface = _gevserver.LogicalNetworkInterface
