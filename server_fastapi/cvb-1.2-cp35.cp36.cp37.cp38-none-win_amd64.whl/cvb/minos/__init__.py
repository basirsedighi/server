""" Common Vision Blox Minos module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/Minos/'>Common Vision Blox-Tool Minos</a>
"""

import cvb as _cvb
import sys as _sys
import os as _os







import _minos

_mbi_id = _minos._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())



SearchResult = _minos.SearchResult

LearnParameters = _minos.LearnParameters

_KernelSize = _minos.KernelSize
KernelSize =  _minos.KernelSize()

_FilterOrder = _minos.FilterOrder
FilterOrder =  _minos.FilterOrder()

_QualityFeedback = _minos.QualityFeedback
QualityFeedback =  _minos.QualityFeedback()

_SearchMode = _minos.SearchMode
SearchMode =  _minos.SearchMode()

_ReadMode = _minos.ReadMode
ReadMode =  _minos.ReadMode()

ClassifierModelInfo = _minos.ClassifierModelInfo

Classifier = _minos.Classifier

TrainingSet = _minos.TrainingSet

ClassifierFactory = _minos.ClassifierFactory

search_all_correlations = _minos.search_all_correlations
search_correlation = _minos.search_correlation
laplace = _minos.laplace
sharpen = _minos.sharpen
dilate = _minos.dilate
erode = _minos.erode
butterworth_high_pass = _minos.butterworth_high_pass
butterworth_low_pass = _minos.butterworth_low_pass
low_pass = _minos.low_pass
edge = _minos.edge
pyramid = _minos.pyramid
user_filter = _minos.user_filter
