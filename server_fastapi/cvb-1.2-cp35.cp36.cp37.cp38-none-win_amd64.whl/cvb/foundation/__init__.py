""" Common Vision Blox Foundation module for Python"""

import cvb as _cvb
import sys as _sys
import os as _os
import platform

_WIN32 = platform.system() == 'Windows'

import _foundation

_mbi_id = _foundation._mbi_id
 
if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())

_CalibrationPiece = _foundation.CalibrationPiece
CalibrationPiece = _foundation.CalibrationPiece()

_IntrinsicCorrectionModel = _foundation.IntrinsicCorrectionModel
IntrinsicCorrectionModel = _foundation.IntrinsicCorrectionModel()

AQS12Piece = _foundation.AQS12Piece

face_segmentation_from_piece = _foundation.face_segmentation_from_piece
calibrator_from_piece = _foundation.calibrator_from_piece
extrinsic_transformation_from_piece = _foundation.extrinsic_transformation_from_piece

if _WIN32:
  _ImageResolution= _foundation.ImageResolution
  ImageResolution = _foundation.ImageResolution()

  _PseudoColorMode= _foundation.PseudoColorMode
  PseudoColorMode= _foundation.PseudoColorMode()

  _Pattern= _foundation.Pattern
  Pattern= _foundation.Pattern()

  convert_to_planes = _foundation.convert_to_planes
  calculate_stokes_image = _foundation.calculate_stokes_image
  calculate_stokes_0 = _foundation.calculate_stokes_0
  calculate_stokes_1 = _foundation.calculate_stokes_1
  calculate_stokes_2 = _foundation.calculate_stokes_2
  calculate_min_reflection_image = _foundation.calculate_min_reflection_image
  colorize_stokes_image = _foundation.colorize_stokes_image


  _PixelOverflow = _foundation.PixelOverflow
  PixelOverflow =  _foundation.PixelOverflow()

  _SqrtPixelScaling = _foundation.SqrtPixelScaling
  SqrtPixelScaling =  _foundation.SqrtPixelScaling()

  _Interpolation = _foundation.Interpolation
  Interpolation =  _foundation.Interpolation()

  _Axis = _foundation.Axis
  Axis =  _foundation.Axis()

  PerspectiveTransformation = _foundation.PerspectiveTransformation

  _TestImageDataType = _foundation.TestImageDataType
  TestImageDataType =  _foundation.TestImageDataType()

  ColorTwistMatrix = _foundation.ColorTwistMatrix

  _StaticThresholding = _foundation.StaticThresholding
  StaticThresholding =  _foundation.StaticThresholding()

  _DynamicThresholdNorm = _foundation.DynamicThresholdNorm
  DynamicThresholdNorm =  _foundation.DynamicThresholdNorm()

  _FixedFilterSize = _foundation.FixedFilterSize
  FixedFilterSize =  _foundation.FixedFilterSize()

  _FilterOrientation = _foundation.FilterOrientation
  FilterOrientation =  _foundation.FilterOrientation()

  _EdgeFilter = _foundation.EdgeFilter
  EdgeFilter =  _foundation.EdgeFilter()

  _RobertsDirection = _foundation.RobertsDirection
  RobertsDirection =  _foundation.RobertsDirection()

  _LutInterpolation = _foundation.LutInterpolation
  LutInterpolation =  _foundation.LutInterpolation()

  LutLevel = _foundation.LutLevel

_RGBConversion = _foundation.RGBConversion
RGBConversion =  _foundation.RGBConversion()

_BayerPattern = _foundation.BayerPattern
BayerPattern =  _foundation.BayerPattern()

_GammaCorrection = _foundation.GammaCorrection
GammaCorrection =  _foundation.GammaCorrection()

if _WIN32:
  _MorphologyMask = _foundation.MorphologyMask
  MorphologyMask =  _foundation.MorphologyMask()

  _DistanceNorm = _foundation.DistanceNorm
  DistanceNorm =  _foundation.DistanceNorm()

  _ValueNormalization = _foundation.ValueNormalization
  ValueNormalization =  _foundation.ValueNormalization()

  _MomentsCalculation = _foundation.MomentsCalculation
  MomentsCalculation =  _foundation.MomentsCalculation()

  _MomentsOrder = _foundation.MomentsOrder
  MomentsOrder =  _foundation.MomentsOrder()

  _MomentsNormalization = _foundation.MomentsNormalization
  MomentsNormalization =  _foundation.MomentsNormalization()

  HuMoments = _foundation.HuMoments

  ImageMoments = _foundation.ImageMoments

  _CorrelationMethod = _foundation.CorrelationMethod
  CorrelationMethod =  _foundation.CorrelationMethod()

  _BlobBorderFilter = _foundation.BlobBorderFilter
  BlobBorderFilter = _foundation.BlobBorderFilter()

  _BlobRangeFilter = _foundation.BlobRangeFilter
  BlobRangeFilter = _foundation.BlobRangeFilter()

  BlobFilter = _foundation.BlobFilter
  BlobResult = _foundation.BlobResult

_EdgeSearchMode = _foundation.EdgeSearchMode
EdgeSearchMode =  _foundation.EdgeSearchMode()

_EdgeType = _foundation.EdgeType
EdgeType =  _foundation.EdgeType()

_ProjectionMode = _foundation.ProjectionMode
ProjectionMode =  _foundation.ProjectionMode()

EdgeResult = _foundation.EdgeResult

EdgeResultPair = _foundation.EdgeResultPair

ProjectionValue = _foundation.ProjectionValue
Projection = _foundation.Projection

Histogram = _foundation.Histogram

if _WIN32:
  _CalibrationPatternContrast = _foundation.CalibrationPatternContrast
  CalibrationPatternContrast =  _foundation.CalibrationPatternContrast()

  _CalibrationPatternStyle = _foundation.CalibrationPatternStyle
  CalibrationPatternStyle =  _foundation.CalibrationPatternStyle()

  _CalibrationPatternFormat = _foundation.CalibrationPatternFormat
  CalibrationPatternFormat =  _foundation.CalibrationPatternFormat()

  _CalibrationPatternOrientation = _foundation.CalibrationPatternOrientation
  CalibrationPatternOrientation =  _foundation.CalibrationPatternOrientation()

  NonLinearTransformation = _foundation.NonLinearTransformation

  add_image = _foundation.add_image
  add_constant = _foundation.add_constant
  multiply_image = _foundation.multiply_image
  multiply_constant = _foundation.multiply_constant
  subtract_image = _foundation.subtract_image
  subtract_constant = _foundation.subtract_constant
  divide_image = _foundation.divide_image
  divide_constant = _foundation.divide_constant
  absolute = _foundation.absolute
  subtract_image_abs = _foundation.subtract_image_abs
  subtract_constant_abs = _foundation.subtract_constant_abs
  square = _foundation.square
  sqrt = _foundation.sqrt
  and_image = _foundation.and_image
  and_constant = _foundation.and_constant
  or_image = _foundation.or_image
  or_constant = _foundation.or_constant
  xor_image = _foundation.xor_image
  xor_constant = _foundation.xor_constant
  negate = _foundation.negate
  upshift = _foundation.upshift
  downshift = _foundation.downshift
  matrix_transform = _foundation.matrix_transform
  mirror = _foundation.mirror
  perspective = _foundation.perspective
  resize = _foundation.resize
  rotate = _foundation.rotate
  shear = _foundation.shear
  add_uniform_noise = _foundation.add_uniform_noise
  add_gauss_noise = _foundation.add_gauss_noise
  create_jaehne_image = _foundation.create_jaehne_image
  create_ramp_image = _foundation.create_ramp_image
  init_aoi = _foundation.init_aoi
  init_image = _foundation.init_image
  sub_image = _foundation.sub_image
  convert_to_rgb = _foundation.convert_to_rgb
  convert_to_yuv = _foundation.convert_to_yuv
  convert_to_ycbcr = _foundation.convert_to_ycbcr
  convert_to_cie_xyz = _foundation.convert_to_cie_xyz
  convert_to_cie_luv = _foundation.convert_to_cie_luv
  convert_to_cie_lab16 = _foundation.convert_to_cie_lab16
  convert_to_cie_lab8 = _foundation.convert_to_cie_lab8
  convert_to_ycc = _foundation.convert_to_ycc
  convert_to_hls = _foundation.convert_to_hls
  convert_to_hsv = _foundation.convert_to_hsv
  convert_to_mono = _foundation.convert_to_mono
  swap_channels = _foundation.swap_channels
  twist_colors = _foundation.twist_colors
  convert_to_8bpp_unsigned = _foundation.convert_to_8bpp_unsigned
  convert_to_16bpp_unsigned = _foundation.convert_to_16bpp_unsigned
  convert_to_16bpp_signed = _foundation.convert_to_16bpp_signed
  convert_to_32bpp_signed = _foundation.convert_to_32bpp_signed
  convert_to_32bpp_float = _foundation.convert_to_32bpp_float
  scale_to_8bpp_unsigned = _foundation.scale_to_8bpp_unsigned
  scale_to_16bpp_unsigned = _foundation.scale_to_16bpp_unsigned
  scale_to_16bpp_signed = _foundation.scale_to_16bpp_signed
  scale_to_32bpp_signed = _foundation.scale_to_32bpp_signed
  scale_to_32bpp_float = _foundation.scale_to_32bpp_float
  static_image_threshold = _foundation.static_image_threshold
  static_constant_threshold = _foundation.static_constant_threshold
  dynamic_threshold = _foundation.dynamic_threshold
  static_transparent_threshold = _foundation.static_transparent_threshold
  range_threshold_to_dst = _foundation.range_threshold_to_dst
  range_threshold = _foundation.range_threshold
  canny = _foundation.canny
  laplace = _foundation.laplace
  sharpen = _foundation.sharpen
  low_pass = _foundation.low_pass
  high_pass = _foundation.high_pass
  gauss = _foundation.gauss
  box_mean = _foundation.box_mean
  box_min = _foundation.box_min
  box_max = _foundation.box_max
  box_median = _foundation.box_median
  color_median = _foundation.color_median
  wiener = _foundation.wiener
  prewitt = _foundation.prewitt
  scharr = _foundation.scharr
  sobel = _foundation.sobel
  sobel_2nd = _foundation.sobel_2nd
  sobel_2nd_cross = _foundation.sobel_2nd_cross
  roberts = _foundation.roberts
  apply_8bit_lut = _foundation.apply_8bit_lut
  apply_interpolated_lut = _foundation.apply_interpolated_lut

create_destination_image = _foundation.create_destination_image
bayer_to_rgb_to_dst = _foundation.bayer_to_rgb_to_dst
bayer_to_rgb = _foundation.bayer_to_rgb
bayer_to_mono = _foundation.bayer_to_mono
rgb_to_bayer = _foundation.rgb_to_bayer
get_white_balance = _foundation.get_white_balance

if _WIN32:
  erode = _foundation.erode
  erode_custom = _foundation.erode_custom
  dilate = _foundation.dilate
  dilate_custom = _foundation.dilate_custom
  open = _foundation.open
  open_custom = _foundation.open_custom
  close = _foundation.close
  close_custom = _foundation.close_custom
  distance_transform = _foundation.distance_transform
  gaussian_pyramid_down = _foundation.gaussian_pyramid_down
  gaussian_pyramid_up = _foundation.gaussian_pyramid_up
  norm_l1 = _foundation.norm_l1
  norm_l2 = _foundation.norm_l2
  norm_linf = _foundation.norm_linf
  local_eigen_values_and_vectors = _foundation.local_eigen_values_and_vectors
  local_min_eigen_values = _foundation.local_min_eigen_values
  wang_quality = _foundation.wang_quality
  correlate = _foundation.correlate
  find_matches = _foundation.find_matches
  binarize_and_search_blobs = _foundation.binarize_and_search_blobs
  search_blobs = _foundation.search_blobs
  circle_regression = _foundation.circle_regression
  ellipse_regression = _foundation.ellipse_regression
  line_regression = _foundation.line_regression

find_first_edge = _foundation.find_first_edge
find_all_edges = _foundation.find_all_edges
find_best_edge = _foundation.find_best_edge
write_projection = _foundation.write_projection
create_image_histograms = _foundation.create_image_histograms
create_plane_histogram = _foundation.create_plane_histogram
filter_histogram = _foundation.filter_histogram
find_histogram_peaks = _foundation.find_histogram_peaks
sum_histogram_between = _foundation.sum_histogram_between

if _WIN32:
  create_calibration_pattern = _foundation.create_calibration_pattern
  create_printable_calibration_pattern = _foundation.create_printable_calibration_pattern
  extract_calibration_lists = _foundation.extract_calibration_lists

