""" Common Vision Blox ShapeFinder module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/ShapeFinder/'>Common Vision Blox-Tool ShapeFinder</a>
"""

import cvb as _cvb
import sys as _sys
import os as _os







import _shapefinder2

_mbi_id = _shapefinder2._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())



_ContrastMode = _shapefinder2.ContrastMode
ContrastMode =  _shapefinder2.ContrastMode()

_PrecisionMode = _shapefinder2.PrecisionMode
PrecisionMode =  _shapefinder2.PrecisionMode()

_GradientType = _shapefinder2.GradientType
GradientType =  _shapefinder2.GradientType()


Classifier = _shapefinder2.Classifier
ClassifierFactory = _shapefinder2.ClassifierFactory
SearchResult = _shapefinder2.SearchResult

edge = _shapefinder2.edge
pyramid = _shapefinder2.pyramid




